import { Asset } from './asset';
import { Location } from './location';

export type AssetState = {
  assets: Asset[];
  locations: Location[];
  setAssets: (assets: Asset[]) => void;
  setLocations: (locations: Location[]) => void;
};

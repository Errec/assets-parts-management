export type Location = {
    id: string;
    name: string;
    parentId?: string | null;
  };
  
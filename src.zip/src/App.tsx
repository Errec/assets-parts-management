import React, { useEffect, useState } from 'react';
import { QueryClientProvider } from 'react-query';
import ErrorBoundary from './components/ui/ErrorBoundary';
import { fetchCompaniesData, fetchCompanyAssetsData, fetchCompanyLocationsData, getErrorMessage, queryClient } from './services/apiService';
import { useAssetStore } from './store';
import { Asset } from './types/asset';
import { Location } from './types/location';

const LoadingSpinner: React.FC = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 rounded-full" role="status">
      <span className="visually-hidden">Loading...</span>
    </div>
  </div>
);

const App: React.FC = () => {
  const setAssets = useAssetStore((state) => state.setAssets);
  const setLocations = useAssetStore((state) => state.setLocations);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log("Fetching companies...");
        const companies = await fetchCompaniesData() as { id: string }[];
        console.log("Companies fetched:", companies);

        for (const company of companies) {
          console.log(`Fetching data for company ${company.id}...`);
          const locations = await fetchCompanyLocationsData(company.id) as Location[];
          console.log(`Locations for company ${company.id}:`, locations);
          const assets = await fetchCompanyAssetsData(company.id) as Asset[];
          console.log(`Assets for company ${company.id}:`, assets);

          setLocations((prev) => [...prev, ...locations]);
          setAssets((prev) => [...prev, ...assets]);
        }
      } catch (error) {
        console.error('Error fetching data:', getErrorMessage(error));
      } finally {
        setLoading(false); // Set loading to false after data is fetched
      }
    };

    fetchData();
  }, [setAssets, setLocations]);

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ErrorBoundary>
        <div className="p-4">
          <h1 className="text-3xl font-bold">Company Data</h1>
          <p></p>
        </div>
      </ErrorBoundary>
    </QueryClientProvider>
  );
};

export default App;

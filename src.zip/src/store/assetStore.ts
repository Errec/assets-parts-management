import { create } from 'zustand';
import { Asset } from '../types/asset';
import { Location } from '../types/location';

interface AssetState {
  assets: Asset[];
  locations: Location[];
  setAssets: (assets: Asset[] | ((prev: Asset[]) => Asset[])) => void;
  setLocations: (locations: Location[] | ((prev: Location[]) => Location[])) => void;
}

export const useAssetStore = create<AssetState>((set) => ({
  assets: [],
  locations: [],
  setAssets: (newAssets) => set((state) => ({
    assets: typeof newAssets === 'function' ? newAssets(state.assets) : newAssets
  })),
  setLocations: (newLocations) => set((state) => ({
    locations: typeof newLocations === 'function' ? newLocations(state.locations) : newLocations
  })),
}));

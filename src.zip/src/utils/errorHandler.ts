export const handleError = (error: any) => {
    console.error('An error occurred:', error);
    // TODO:Implement further logging or error handling logic here
  };
  
import ContainerHeader from "../template/ContainerHeader"

function Container() {
  return (
    <main>
        <ContainerHeader />
    </main>
  )
}

export default Container